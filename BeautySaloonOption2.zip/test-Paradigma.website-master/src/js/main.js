$(document).ready(function() {
 //Скрипт для мобильного меню
 var button = $("#button");
 var menu = $("#menu");
 var close = $("#close");
 button.on('click', function() {
  menu.addClass ('header-menu__active');
 });
 close.on('click', function() {
  menu.removeClass ('header-menu__active');
 });



 //Скрипт для всплывающей подсказки
var help = $("#help");
$("#i, #help").mouseover(function(){
  help.addClass ("hero-unit_active");
});

$("#i, #help").mouseout(function(){
  help.removeClass ("hero-unit_active");
});

 //Скрипт для всплывающей карты
 var map = $("#map");
 $("#map_active, #map").mouseover(function(){
   map.addClass ("header-map_active");
 });
 
 $("#map_active, #map").mouseout(function(){
   map.removeClass ("header-map_active");
 });
 //Скрипт для реллакс эффекта
  var rellax = new Rellax('.rellax');
});
