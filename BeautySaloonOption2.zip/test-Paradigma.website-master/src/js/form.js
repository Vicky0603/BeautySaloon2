//скрипт для отправки окна "ваш заказ принят"
$(document).ready(function(){
$('#offer-form').on('submit', function(event) {
 event.preventDefault();
 $.ajax({
  url: 'php/mail.php',
  type: 'POST',
  data: $(this).serialize(),
  success: function(data){
   $('.modal1').addClass('modal_active');
   $('.modal').removeClass('modal_active');
  }
 });
});
});