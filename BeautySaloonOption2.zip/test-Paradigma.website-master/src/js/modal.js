//скрипт для главного окна
$(document).ready(function(){
  var button1 = $('#button-modal,#button-modal1');
  var modal = $('#modal');
  var close1 = $('#close-modal');
  var modal1 = $('#modal1');
  var close2 = $('#close-modal1');
  
  button1.on('click', function(){
  modal.addClass('modal_active')
  });
  
  close1.on('click', function(){
   modal.removeClass('modal_active')
  });
  //скрипт для закрытия окна "ваш заказ принят"
  close2.on('click',function() {
    modal1.removeClass('modal_active');
  });
  });

