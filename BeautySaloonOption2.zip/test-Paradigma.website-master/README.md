# test-Paradigma.website
Тестовое задание на позицию HTML-верстальщика в компанию Paradigma.website
